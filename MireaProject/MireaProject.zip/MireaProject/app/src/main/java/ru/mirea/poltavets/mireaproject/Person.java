package ru.mirea.poltavets.mireaproject;

import java.util.ArrayList;
import java.util.List;

public class Person {
    String name, age;
    int photoId;
    Person(String name, String age, int photoId){
        this.name = name;
        this. age = age;
        this.photoId = photoId;
    }
}
